

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
 import java.util.List;


public class News{

    public static WebDriver driver = new ChromeDriver();

    public static void main(String [] args){
        System.out.println("this is check");
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        AddisFortune();
        driver.close();


    }
    public static String AddisFortune() {
        driver.get("https://addisfortune.net/");
        String title = driver.getTitle();
        String a = driver.getCurrentUrl();
        String b = driver.getPageSource();
        WebElement lists = driver.findElement(By.xpath("//*[@id=\"addisfortune-main\"]/div/div[1]/div[2]/div"));
        List<WebElement> header_news= (List<WebElement>)lists.findElements(By.tagName("h3"));
        List<WebElement> body= (List<WebElement>)lists.findElements(By.className("row"));

        System.out.println(header_news.size());
        String Web = "<head><link rel=\"stylesheet\" type=\"text/css\" href=\"newcss.css\"></head>";
         Web= Web + "<div class=\"conatain\">";
        for(int i = 0 ;i<header_news.size() ;i++){

            if(header_news.size()<1){break;}
            Web = Web + "<div class=\"single\">";
            Web = Web +header_news.get(i).getAttribute("innerHTML");
            Web = Web +body.get(i).findElement(By.className("span2")).getAttribute("innerHTML");
            Web = Web +body.get(i).findElement(By.className("span4")).getAttribute("innerHTML");
            Web = Web +"</div>";
        }
        Web = Web +"</div>";
        return  Web;
    }

}
