#ifndef FooH
#define FooH

class Foo
{
public:UInt32 GetNumberChannels() const;

    private:UInt32 _numberChannels;
	};

	#endif
