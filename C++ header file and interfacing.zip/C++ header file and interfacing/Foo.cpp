#include "Foo.h"

UInt32 Foo::GetNumberChannels() const
{
    return _numberChannels;
    }
