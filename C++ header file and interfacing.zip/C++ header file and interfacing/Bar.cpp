#include "Foo.h"

Foo f;
UInt32 chans = f.GetNumberChannels();
